
/** \file b64/cpp/b64.hpp
 *
 * \brief [OBSOLETE] Former header file for the b64 library for C++
 *   compilation units.
 *
 * \deprecated Instead include b64/b64.hpp
 */

#ifndef STLSOFT_INCL_STLSOFT_H_STLSOFT
# include <stlsoft/stlsoft.h>
#endif /* !STLSOFT_INCL_STLSOFT_H_STLSOFT */

#ifdef STLSOFT_CF_PRAGMA_MESSAGE_SUPPORT
# pragma message("This file (b64/cpp/b64.hpp) is now obsolete, and will be removed in a future release. Instead include b64/b64.hpp")
#endif /* STLSOFT_CF_PRAGMA_MESSAGE_SUPPORT */

#include <b64/b64.hpp>

/* Compatibility
[<[STLSOFT-AUTO:NO-DOCFILELABEL]>]
[<[STLSOFT-AUTO:NO-UNITTEST]>]
*/
