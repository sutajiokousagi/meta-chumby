#ifndef __FB_H__
#define __FB_H__


#define FRAMEBUFFER_BYTES (320*240*2)



#endif //__FB_H__
