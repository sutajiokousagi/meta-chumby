#ifndef __I2C_H__
#define __I2C_H__


unsigned int eeprom_read(unsigned char addr, unsigned short offset);

#endif // __I2C_H__
