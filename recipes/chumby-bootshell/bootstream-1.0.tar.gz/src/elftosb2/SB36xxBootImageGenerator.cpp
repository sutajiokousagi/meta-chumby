/*
 * File:	SB36xxBootImageGenerator.cpp
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */

#include "SB36xxBootImageGenerator.h"
#include "Logging.h"

//! Name of the option that sets the required alignment for the
//! start of the user data region.
#define kUserDataAlignmentOption "userDataAlignment"

//! Name of option used to set the ROM version field of the .sb file.
#define kROMVersionOption "romVersion"

//! Name of option to turn on support for multiple sections in the .sb format.
#define kEnableSectionsOption "enableSections"

using namespace elftosb;

BootImage * SB36xxBootImageGenerator::generate()
{
    // create the output image
	St3600IPL * image = new St3600IPL();
	
	// handle global options that affect the image
	processOptions(image);
	
	// process each output section
    bool processedOps = false;
    bool processedUserData = false;
	section_vector_t::iterator it = m_sections.begin();
	for (; it != m_sections.end(); ++it)
	{
		OutputSection * section = *it;
		
        // is this an operations section?
		OperationSequenceSection * opSection = dynamic_cast<OperationSequenceSection*>(section);
		if (opSection)
		{
            // ignore this section if we've already encountered another ops section
			// and support for multiple sections is disabled
            if (!m_enableSections && processedOps)
            {
                Log::log(Logger::WARNING, "warning: multiple operation sections are not supported in the STMP36xx .sb format unless the enableSections option is turned on\n");
                continue;
            }
            
			processOperationSection(opSection, image);
			processedOps = true;
            continue;
		}
		
        // is this a data section?
		BinaryDataSection * dataSection = dynamic_cast<BinaryDataSection*>(section);
		if (dataSection)
		{
            // only one user data section is allowed
            if (processedUserData)
            {
                Log::log(Logger::WARNING, "warning: multiple data sections are not supported in the STMP36xx .sb format\n");
                continue;
            }
            
			processDataSection(dataSection, image);
            processedUserData = true;
            continue;
		}
		
        // we don't know what it is!
		Log::log(Logger::WARNING, "warning: unexpected output section type\n");
	}
	
	return image;
}

void SB36xxBootImageGenerator::processOptions(St3600IPL * image)
{
	// bail if no option context was set
	if (!m_options)
	{
		return;
	}
	
	const IntegerValue * intValue;
	
	if (m_options->hasOption(kUserDataAlignmentOption))
	{
		intValue = dynamic_cast<const IntegerValue *>(m_options->getOption(kUserDataAlignmentOption));
		if (intValue)
		{
			image->setUserDataAlignment(intValue->getValue());
		}
        else
        {
            Log::log(Logger::WARNING, "warning: userDataAlignment option is an unexpected type\n");
        }
	}
	
	if (m_options->hasOption(kROMVersionOption))
	{
		intValue = dynamic_cast<const IntegerValue *>(m_options->getOption(kROMVersionOption));
		if (intValue)
		{
			image->setROMVersion(intValue->getValue());
		}
        else
        {
            Log::log(Logger::WARNING, "warning: romVersion option is an unexpected type\n");
        }
	}
	
	if (m_options->hasOption(kEnableSectionsOption))
	{
		intValue = dynamic_cast<const IntegerValue *>(m_options->getOption(kEnableSectionsOption));
		if (intValue)
		{
			m_enableSections = intValue->getValue() != 0;
		}
        else
        {
            Log::log(Logger::WARNING, "warning: enableSections option is an unexpected type\n");
        }
	}
	
    // handle common options
	processVersionOptions(image);
	processDriveTagOption(image);
}

void SB36xxBootImageGenerator::processOperationSection(OperationSequenceSection * section, St3600IPL * image)
{
	// Insert a section tag if support for multiple sections is enabled.
	if (m_enableSections)
	{
		image->addSectionTagCommand(false, section->getIdentifier());
	}
	
	// Iterate over ops in this section and convert them to boot commands.
	OperationSequence & sequence = section->getSequence();
	OperationSequence::iterator_t it = sequence.begin();
	for (; it != sequence.end(); ++it)
	{
		Operation * op = *it;
		
		LoadOperation * loadOp = dynamic_cast<LoadOperation*>(op);
		if (loadOp)
		{
			processLoadOperation(loadOp, image);
			continue;
		}
		
		ExecuteOperation * execOp = dynamic_cast<ExecuteOperation*>(op);
		if (execOp)
		{
			processExecuteOperation(execOp, image);
			continue;
		}
		
		BootModeOperation * modeOp = dynamic_cast<BootModeOperation*>(op);
		if (modeOp)
		{
			processBootModeOperation(modeOp, image);
			continue;
		}
		
		Log::log(Logger::WARNING, "warning: unexpected operation type\n");
	}
}

void SB36xxBootImageGenerator::processLoadOperation(LoadOperation * op, St3600IPL * image)
{
	DataSource * source = op->getSource();
	DataTarget * target = op->getTarget();
	
	// other sources get handled the same way
	unsigned segmentCount = source->getSegmentCount();
	unsigned index = 0;
	for (; index < segmentCount; ++index)
	{
		DataSource::Segment * segment = source->getSegmentAt(index);
		DataTarget::AddressRange range = target->getRangeForSegment(*source, *segment);
		unsigned rangeLength = range.m_end - range.m_begin;
		
		// handle a pattern segment as a special case to create a fill command
		DataSource::PatternSegment * patternSegment = dynamic_cast<DataSource::PatternSegment*>(segment);
		if (patternSegment)
		{
			SizedIntegerValue & pattern = patternSegment->getPattern();
			image->addPatternFillCommand(false, range.m_begin, rangeLength, pattern.getValue(), pattern.getSize());
			continue;
		}
		
		// get the data from the segment
		uint8_t * data = new uint8_t[rangeLength];
		segment->getData(0, rangeLength, data);
		
		// create the boot command
		image->addLoadDataBlockCommand(false, range.m_begin, data, rangeLength);
	}
}

void SB36xxBootImageGenerator::processExecuteOperation(ExecuteOperation * op, St3600IPL * image)
{
	DataTarget * target = op->getTarget();
	uint32_t arg = static_cast<uint32_t>(op->getArgument());
	
	switch (op->getExecuteType())
	{
		case ExecuteOperation::kJump:
			image->addJumpCommand(false, target->getBeginAddress(), arg);
			break;
		
		case ExecuteOperation::kCall:
			image->addJumpAndReturnCommand(false, target->getBeginAddress(), arg);
			break;
	}
}

void SB36xxBootImageGenerator::processBootModeOperation(BootModeOperation * op, St3600IPL * image)
{
	image->addSwitchDriverCommand(false, op->getBootMode());
}

void SB36xxBootImageGenerator::processDataSection(BinaryDataSection * section, St3600IPL * image)
{
	image->setUserData(section->getData(), section->getLength());
}

