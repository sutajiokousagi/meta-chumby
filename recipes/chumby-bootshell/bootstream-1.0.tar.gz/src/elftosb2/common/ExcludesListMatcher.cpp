/*
 * File:	ExcludesListMatcher.cpp
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */

#include "ExcludesListMatcher.h"

using namespace elftosb;

ExcludesListMatcher::ExcludesListMatcher()
:	GlobMatcher("")
{
}

ExcludesListMatcher::~ExcludesListMatcher()
{
}

//! \param isInclude True if this pattern is an include, false if it is an exclude.
//! \param pattern String containing the glob pattern.
void ExcludesListMatcher::addPattern(bool isInclude, const std::string & pattern)
{
	glob_list_item_t item;
	item.m_isInclude = isInclude;
	item.m_glob = pattern;
	
	// add to end of list
	m_patterns.push_back(item);
}

//! If there are no entries in the match list, the match fails.
//!
//! \param testValue The string to match against the pattern list.
//! \retval true The \a testValue argument matches.
//! \retval false No match was made against the argument.
bool ExcludesListMatcher::match(const std::string & testValue)
{
	if (!m_patterns.size())
	{
		return false;
	}
	
	// iterate over the match list
	glob_list_t::iterator it = m_patterns.begin();
	for (; it != m_patterns.end(); ++it)
	{
		glob_list_item_t & item = *it;
		
		// if this pattern is an include and it doesn't match, or
		// if this pattern is an exclude and it does match, then the match fails
		bool isMatch = globMatch(testValue.c_str(), item.m_glob.c_str());
		if ((item.m_isInclude && !isMatch) || (!item.m_isInclude && isMatch))
		{
			return false;
		}
	}
	
	return true;
}

