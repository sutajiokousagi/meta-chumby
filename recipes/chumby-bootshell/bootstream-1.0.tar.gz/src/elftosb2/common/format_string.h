/*
 * File:	format_string.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_format_string_h_)
#define _format_string_h_

#include <string>
#include <stdexcept>

/*!
 * \brief Returns a formatted STL string using printf format strings.
 */
std::string format_string(const char * fmt, ...);


#endif // _format_string_h_

