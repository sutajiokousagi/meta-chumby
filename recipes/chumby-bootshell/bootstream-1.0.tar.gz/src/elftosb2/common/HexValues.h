/*
 * File:	HexValues.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_HexValues_h_)
#define _HexValues_h_

#include "stdafx.h"

//! \brief Determines whether \a c is a hex digit character.
bool isHexDigit(char c);

//! \brief Converts a hexidecimal character to the integer equivalent.
uint8_t hexCharToInt(char c);

//! \brief Converts a hex-encoded byte to the integer equivalent.
uint8_t hexByteToInt(const char * encodedByte);

#endif // _HexValues_h_
