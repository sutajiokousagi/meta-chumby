/*
 * File:	ExcludesListMatcher.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_ExcludesListMatcher_h_)
#define _ExcludesListMatcher_h_

#include "GlobMatcher.h"
#include <vector>
#include <string>

namespace elftosb
{

/*!
 * \brief Matches strings using a series of include and exclude glob patterns.
 *
 * This string matcher class uses a sequential, ordered list of glob patterns to
 * determine whether a string matches.  Attached to each pattern is an include/exclude
 * action. If the first pattern in the list is an include then the filter starts out
 * matching only the strings matched by the first pattern. If the first pattern is an
 * exclude, then it starts out matching all strings but those matched by that pattern.
 * After the first pattern, each further glob pattern in the list filters strings
 * matched by earlier patterns.
 *
 * The only reason for inheriting from GlobMatcher is so we can access the protected
 * globMatch() method.
 */
class ExcludesListMatcher : public GlobMatcher
{
public:
	//! \brief Default constructor.
	ExcludesListMatcher();
	
	//! \brief Destructor.
	~ExcludesListMatcher();
	
	//! \name Pattern list
	//@{
	//! \brief Add one include or exclude pattern to the end of the match list.
	void addPattern(bool isInclude, const std::string & pattern);
	//@}
	
	//! \brief Performs a single string match test against testValue.
	virtual bool match(const std::string & testValue);

protected:
	//! \brief Information about one glob pattern entry in a match list.
	struct glob_list_item_t
	{
		bool m_isInclude;	//!< True if include, false if exclude.
		std::string m_glob;	//!< The glob pattern to match.
	};
	
	typedef std::vector<glob_list_item_t> glob_list_t;
	glob_list_t m_patterns;	//!< Ordered list of include and exclude patterns.
};

}; // namespace elftosb

#endif // _ExcludesListMatcher_h_
