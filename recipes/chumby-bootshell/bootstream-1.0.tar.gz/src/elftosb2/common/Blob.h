/*
 * File:	Blob.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_Blob_h_)
#define _Blob_h_

#include "stdafx.h"

/*!
 * \brief Manages a binary object of arbitrary length.
 *
 * The data block is allocated with malloc() instead of the new
 * operator so that we can use realloc() to resize it.
 */
class Blob
{
public:
	//! \brief Default constructor.
	Blob();
	
	//! \brief Constructor.
	Blob(const uint8_t * data, unsigned length);
	
	//! \brief Copy constructor.
	Blob(const Blob & other);
	
	//! \brief Destructor.
	virtual ~Blob();
	
	void setData(const uint8_t * data, unsigned length);
	
	void setLength(unsigned length);
		
	uint8_t * getData() { return m_data; }
	const uint8_t * getData() const { return m_data; }
	unsigned getLength() const { return m_length; }
	
	void append(const uint8_t * newData, unsigned newDataLength);

protected:
	uint8_t * m_data;	//!< The binary data held by this object.
	unsigned m_length;	//!< Number of bytes pointed to by #m_data.
};

#endif // _Blob_h_

