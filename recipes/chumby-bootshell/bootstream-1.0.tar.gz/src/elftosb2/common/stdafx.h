#ifndef stdafx_h_
#define stdafx_h_

// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

// Default to external release.
#ifndef SGTL_INTERNAL
    #define SGTL_INTERNAL 0
#endif

#include <iostream>
#include <stdexcept>

#if defined(WIN32)
//#include <tchar.h>
#endif

#if !defined(WIN32)
// The standard way of getting types like uint32_t is through <stdint.h>. Try that
// everywhere but Windows.
#include <stdint.h>
#endif // !defined(WIN32)


#if defined(WIN32)
// redefine missing typedefs from stdint.h or syst/types.h

typedef unsigned long uint32_t;
typedef unsigned short uint16_t;
typedef unsigned char uint8_t;

typedef long int32_t;
typedef short int16_t;
typedef char int8_t;
#endif // defined(WIN32)

#define TRUE 1
#define FALSE 0

#endif // stdafx_h_
