/*
 * File:	St3600IPL.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_St3600IPL_h_)
#define _St3600IPL_h_

#include "stdafx.h"
#include "StExecutableImage.h"
#include "StKeySet.h"
#include <list>
#include <iostream>
#include "BootImage.h"

/*!
 * The set of bootloader commands.
 */
enum {
	RESERVED_CMD = 0x00,				//!< Bit pattern 0000.
	LOAD_DATA_BLOCK_CMD = 0x01,			//!< Bit pattern 0001.
	PATTERN_FILL_CMD = 0x02,			//!< Bit pattern 0010.
	BOOTLOADING_COMPLETE_CMD = 0x03,	//!< Bit pattern 0011.
	JUMP_AND_RETURN_CMD = 0x04,			//!< Bit pattern 0100.
	SWITCH_DRIVER_CMD = 0x05,			//!< Bit pattern 0101.
	INITIALIZE_SDRAM_CMD = 0x06,        //!< Bit pattern 0110.
	ENABLE_PROGRESS_CODES_CMD = 0x07,    //!< Bit pattern 0111.
	SECTION_TAG_CMD = 0x08				//!< Bit pattern 1000.
};

/*!
 * Various length constants.
 */
enum {
	IPL_BLOCK_LENGTH = 512,			//!< Number of bytes in a bootloader block.
	
	IPL_HEADER_TAG_LENGTH = 4,		//!< Four bytes for the "STMP" magic number in the first bootloader block.
	IPL_BCD_VERSION_LENGTH = 12		//!< The number of BCD digits in the versions in the first bootloader block.
};

//! Magic number for the tag field of the header in the first
//! block of the output bootloader image.
#define IPL_HEADER_TAG "STMP"

/*!
 * Constants pertaining to version numbers.
 */
enum {
	IPL_DEFAULT_VERSION_NUMBER = 0x9999,
	IPL_VERSION_NUMBER_MASK = 0xffff
};

/*!
 * Constants for maximum bootloader command field values.
 */
enum {
	//! The maximum number of words in the cmd_length field.
	IPL_MAX_CMD_LENGTH = 2047,
	
	//! The maximum number of bytes specifyable by the byte_count field of a bootloader command.
	IPL_MAX_BYTE_COUNT = 16383,
	
	//! The actual maximum number of bytes in words 2-N in a bootloader command.
	IPL_MAX_DATA_LENGTH = ((IPL_MAX_CMD_LENGTH * sizeof(uint32_t)) - sizeof(uint32_t))
};

// forward declarations
class StEncrypter;

/*!
 * \brief Manages an initial program load (IPL) layout for the 3600.
 */
class St3600IPL : public elftosb::BootImage
{
public:
	//! \brief Constructor.
	St3600IPL();
	
	//! \brief Destructor.
	virtual ~St3600IPL();
	
	//! \brief Specify the drive tag to be set in the output file header.
	virtual void setDriveTag(uint16_t tag) { m_driveTag = tag; }
	
	//! \name Versions
	//@{
	inline void setROMVersion(uint32_t inVersion) { m_romVersion = inVersion; }
	void setProductVersion(unsigned inMajor, unsigned inMinor, unsigned inRevision);
	void setComponentVersion(unsigned inMajor, unsigned inMinor, unsigned inRevision);
    
	virtual void setProductVersion(const elftosb::version_t & version) { setProductVersion(version.m_major, version.m_minor, version.m_revision); }
	virtual void setComponentVersion(const elftosb::version_t & version) { setComponentVersion(version.m_major, version.m_minor, version.m_revision); }
	//@}
	
	//! \name Encryption and authentication
	//@{
	//! \brief Sets the raw key block that is modified by the transform code.
	//! Makes a copy of the key block. The key block is not included in the output
	//! image, but is used to encrypt and authenticate the image. The key set must
	//! be pre-transformed. The receiver will not transform the key set when a
	//! key tranform code is set.
	inline void setKeySet(const StKeySet & inKeys) { m_keySet = inKeys; }
	
	//! \brief Sets the transform code used to generate the actual keys from the raw key block.
	inline void setKeyTransformCode(uint32_t inKeyTransform) { m_keyTransform = inKeyTransform; }
	
	//! \brief Sets the encryption and authentication algorithm.
	//!
	//! The encrypter is not taken over by the layout object. It is still the responsibility
	//! of the caller to dispose of it.
	inline void setEncrypter(StEncrypter * inEncrypter) { m_encrypter = inEncrypter; }
	//@}
	
	//! \name Bootloader commands
	//@{
	//! \brief Add an arbitrary boot command.
	virtual void addBootCommand(bool inCritical, unsigned inCommand, unsigned inDataType, uint32_t inAddress, const uint8_t * inData, unsigned inDataLength);
	
	//! \brief Add command to load a block of data into memory.
	virtual void addLoadDataBlockCommand(bool inCritical, uint32_t inAddress, const uint8_t * inData, unsigned inDataLength);
	
	//! \brief Add command to fill a block of memory with a bit pattern.
	virtual void addPatternFillCommand(bool inCritical, uint32_t inAddress, unsigned inFillLength, unsigned inPattern, unsigned inPatternLength);
	
	//! \brief Add command to signal the end of bootloading and to jump to a physical address.
	virtual void addJumpCommand(bool inCritical, uint32_t inAddress, uint32_t inArg);
	
	//! \brief Add command to jump to an address and return to the bootloader when finished.
	virtual void addJumpAndReturnCommand(bool inCritical, uint32_t inAddress, uint32_t inArg);
	
	//! \brief Add command to change the bootloader driver.
	virtual void addSwitchDriverCommand(bool inCritical, uint32_t inFunctionTableAddress);
	
	//! \brief Add command to configure and enable SDRAM interface.
	virtual void addInitializeSDRAMCommand(bool inCritical, uint16_t inChipEnable, uint16_t inSDRAMSize);
	
	//! \brief Add command to turn on emission of progress codes from the Debug UART.
	virtual void addEnableProgressCodesCommand(bool inCritical, int inVerbosity);
	
	//! \brief Add command to identify the start of a section.
	virtual void addSectionTagCommand(bool inCritical, uint32_t sectionName);
	//@}
	
	//! \name User data
	//@{
	//! \brief Specifies the user data appended to the output.
	virtual void setUserData(const uint8_t * inData, unsigned inDataLength);
    
    //! \brief Sets the required alignment for the start of the user data.
    void setUserDataAlignment(unsigned alignment);
	//@}
	
	//! \name Executable image support
	//@{
	//! \brief Adds the commands necessary to load the given image.
	virtual void addExecutableImage(const StExecutableImage & inImage, bool inCritical, bool inJump=true, bool inReturn=true, uint32_t inJumpArg=0);
	//@}
	
	//! \name Writing
	//@{
	//! \brief Formats and outputs the initial program load.
	virtual void writeToStream(std::ostream & inStream);
	//@}
	
	//! \brief Returns a string containing the preferred file extension for image format.
	virtual std::string getFileExtension() const { return ".sb"; }
	
	//! \name Debugging
	//@{
	//! \brief Write the bootloader commands to stdout.
	virtual void dumpCommands();
	//@}

protected:
	/*!
	 * Simple structure containing the three components of a version number.
	 */
	struct Version
	{
		uint16_t m_major;		//!< Major version number.
		uint16_t m_pad0;
		uint16_t m_minor;		//!< Minor version number.
		uint16_t m_pad1;
		uint16_t m_revision;	//!< Revision number.
		uint16_t m_pad2;
	};
	
	uint32_t m_romVersion;	//!< Arbitrary version number.
	Version m_productVersion;	//!< Product version.
	Version m_componentVersion;	//!< Component version.
	uint16_t m_driveTag;    //!< System drive tag.
	
	StKeySet m_keySet;	//!< Raw key block.
	uint32_t m_keyTransform;	//!< Encryption key transform code applied to the raw keys.
	
	StEncrypter * m_encrypter;	//!< The encryption algorithm.
	
	uint8_t * m_userData;	//!< Pointer to user data. May be NULL.
	unsigned m_userDataLength;	//!< The number of bytes pointed to by #m_userData.
    unsigned m_userDataAlignment;    //!< Alignment of user data.
	
	/*!
	 * \brief Command entry in the IPL layout.
	 *
	 * This structure contains the values of bootloader command fields, but they
	 * are not in the actual format required by the bootloader. The method
	 * #formatCommandHeader() is responsible for building the actual header that
	 * appears in the output boot image.
	 */
	struct LayoutEntry
	{
		unsigned m_commandLength;	//!< Number of 32-bit words in the command that follow word 0. Includes #m_dataLength, rounded up to the nearest word.
		unsigned m_dataType;		//!< Size of the data for memory fills.
		unsigned m_bootCommand;		//!< The bootloader command.
		uint32_t m_destinationAddress;	//!< 32-bit physical destination address.
		uint32_t m_byteCount;		//!< The value for the byte_count field. This is used differently depending on the command. Usually it will be equal to #m_dataLength.
		uint8_t * m_data;				//!< Pointer to data for command, or NULL if there is none.
		unsigned m_dataLength;		//!< Number of bytes of data pointed to by #m_data.
		bool m_isCritical;			//!< Is the command critical or not?
		
		//! Returns the total number of bytes occupied by the bootloader command as
		//! it will appear in the output image. This includes word 0 and any padding
		//! bytes after the data. The padding is required in order to have the length
		//! aligned to a four-byte boundary.
		inline unsigned getCommandLengthInBytes() const { return (m_commandLength + 1) * sizeof(uint32_t); }
	};
	
	typedef std::list<LayoutEntry> LayoutEntryList;	//!< The type used to hold LayoutEntry elements.
	
	LayoutEntryList m_layout;	//!< All of the bootloader commands in sequence.
	LayoutEntryList::iterator m_firstNonCriticalEntry;	//!< The first non-critical layout entry.
	
	/*!
	 * The header for the first 512-byte block in the boot image. The layout of this
	 * structure matches exactly how the header appears in the output image.
	 */
	struct FirstBlockHeader
	{
		uint32_t m_romVersion;			//!< Version of the ROM boot command set.
		uint32_t m_imageSize;			//!< The total number of bytes in the image, from the ROM version through the user data.
		uint32_t m_ciphertextOffset;	//!< Offset to first encrypted byte. By definition, this is also the offset to the first bootloader command.
		uint32_t m_userDataOffset;		//!< Offset to the start of user data from the start of the image.
		uint32_t m_keyTransformCode;	//!< Modifier to transform key set into final keys.
		uint8_t m_tag[IPL_HEADER_TAG_LENGTH];	//!< A magic number to identify the image.
		Version m_productVersion;		//!< BCD product version.
		Version m_componentVersion;		//!< BCD component version.
		uint16_t m_reserved;			//!< Reserved field.
		uint16_t m_driveTag;            //!< System drive tag for this .sb file.
	};
	
	/*!
	 * \brief Internal class used to build output IPL blocks.
	 *
	 * The primary purpose of this class is to encapsulate the specifics
	 * of how blocks are put together into a single, small unit of code.
	 */
	class WorkingBlock
	{
	public:
		//! \brief Constructor.
		WorkingBlock();
		
		//! \brief Destructor.
		~WorkingBlock();
		
		//! \brief Writes as much of \a inBytes into the block as possible.
		unsigned writeBytes(const void * inBytes, unsigned inLength);
		
		//! \brief Writes either all or none of \a inBytes into the block.
		bool writeBytesRequired(const void * inBytes, unsigned inLength);
		
		//! \brief Sets the block's 4-byte authentication signature.
		void setSignature(uint32_t inSignature);
		
		//! \brief Returns true if there is no more room for data in the block.
		inline bool isFull() const { return m_free == 0; }
		
		//! \brief Returns the number of bytes that can be written into the block before it is full.
		inline unsigned getFreeByteCount() const { return m_free; }
		
		//! \brief Restore the block to its empty state.
		void reset();
		
		//! \brief Writes the block data to \a inStream.
		void writeToStream(std::ostream & inStream);
		
		//! \brief Returns a pointer to the raw data buffer for the block.
		inline uint8_t * getMutableData() { return m_data; }
		
		//! \brief Returns the total number of bytes in the buffer for the block.
		inline unsigned getLength() const { return IPL_BLOCK_LENGTH; }
		
		//! \brief Encrypts the block contents and sets the authentication signature.
		void encryptAndSign(StEncrypter * inAlgorithm);
		
		//! \brief Sets the number of bytes at the beginning of the block that are not encrypted.
		void setUnencryptedHeaderLength(unsigned inLength) { m_headerLength = inLength; }
		
	protected:
		uint8_t * m_data;	//!< Pointer to data buffer for this block.
		unsigned m_free;	//!< Number of free bytes in the block.
		uint8_t * m_cursor;	//!< The write head within the block.
		unsigned m_headerLength;	//!< Unencrypted header length.
	};
	
	friend std::ostream & operator << (std::ostream & inStream, St3600IPL::WorkingBlock & inBlock);

	/*!
	 * Information used to keep track of the current bootloader command
	 * as it is written to the output image blocks.
	 */
	struct CommandOutputState
	{
		LayoutEntryList & m_layout;		//!< The list of bootloader commands.
		LayoutEntryList::const_iterator m_iterator;	//!< Iterator over bootloader commands.
		unsigned m_remainingBytes;		//!< Number of bytes left to write for the current command.
		unsigned m_cursorIndex;			//!< 
		uint32_t m_header[2];			//!< The current command's formatted header words.
		bool m_isHeaderBuilt;			//!< Has the current command's header been built yet?
		
		//! \brief Constructor.
		CommandOutputState(LayoutEntryList & inLayout);
		
		//! \brief Advance to next bootloader command.
		void nextCommand();
		
		//! \brief Returns true when there are no more commands to process.
		bool isAtEnd() const { return m_iterator == m_layout.end(); }
	};
	
protected:
	//! \brief Inserts \a inEntry in the layout based on its criticality.
	void insertLayoutEntry(LayoutEntry & inEntry);
	
	//! \brief Fills \a ioBlock with formatted commands.
	void writeCommandsIntoBlock(WorkingBlock & ioBlock, CommandOutputState & ioState);
	
	//! \brief Utility to format a bootloader command header.
	void formatCommandHeader(const LayoutEntry & inEntry, uint32_t * ioCommandBytes);
	
    //! \brief Converts a host endian BCD value to the equivalent big-endian BCD.
	uint16_t fixBCDByteOrder(unsigned hostEndianBCD);
	
	//! \brief Computes section lengths and updates section tags with those lengths.
	void fixUpSectionTags();
};

//! Simple operator to allow easy writing of St3600IPL::WorkingBlock instances
//! to a std::ostream.
inline std::ostream & operator << (std::ostream & inStream, St3600IPL::WorkingBlock & inBlock)
{
	inBlock.writeToStream(inStream);
	return inStream;
}

//! Amount of free space in all IPL blocks but the first.
#define IPL_OTHER_BLOCK_ROOM (IPL_BLOCK_LENGTH - sizeof(uint32_t))

//! Amount of free space in the first bootloader image block.
#define IPL_FIRST_BLOCK_ROOM ((IPL_OTHER_BLOCK_ROOM) - sizeof(FirstBlockHeader))

#endif // _St3600IPL_h_
