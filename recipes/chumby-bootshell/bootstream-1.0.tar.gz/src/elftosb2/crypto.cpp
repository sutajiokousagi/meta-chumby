/*
 * File:	crypto.c
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */

#include "crypto.h"


#if OLD_CRYPTO

uint32_t CRYPTO_ParallelPseudoRandomNumberGenerator(uint32_t *pu32)
{
     uint32_t u32_0,u32_1,u32_2;
     u32_0 = pu32[0];
     pu32[0] = pu32[1] ^ pu32[3]  ^ pu32[5]  ^ pu32[7] 
                       ^ pu32[11] ^ pu32[13] ^ pu32[0];
     pu32[1] = pu32[2];
     pu32[2] = pu32[2] ^ pu32[3];
     pu32[3] = pu32[4];
     pu32[4] = pu32[5];
     pu32[5] = pu32[6];
     pu32[6] = pu32[7];
     pu32[7] = pu32[7] ^ pu32[8];
     pu32[8] = pu32[9];
     pu32[9] = pu32[10];
     u32_1 = pu32[11]<<7;
     u32_1 = u32_1 & 0xfffffF80l;   //uncomment this one for 32 bit architectures
     u32_2 = pu32[11]>>25;          //uncomment this one for 32 bit architectures
     u32_2 = u32_2 & 0x0000007fl;
     pu32[10] = u32_1 | u32_2;
     //pu32[10]= pu32[11]; uncomment to remove the bit diffusion
     pu32[11] = pu32[11] ^ pu32[12];
     pu32[12] = pu32[13];
     pu32[13] = pu32[14];
     pu32[14] = pu32[15];
     pu32[15] = u32_0;
     return pu32[0];
}

void CRYPTO_Step(uint32_t number_steps, uint32_t * pu32)
{
	unsigned i;
	for (i = 0; i < number_steps; ++i)
	{
		CRYPTO_ParallelPseudoRandomNumberGenerator(pu32);
	}
}

//! The arguments \a master_key_set and \a transformed_key_set may point to the same key set.
void CRYPTO_TransformKeySet(uint32_t modifier, uint32_t number_steps, key_set_t* master_key_set, key_set_t* transformed_key_set)
{
	// only copy if different
	if (master_key_set != transformed_key_set)
	{
		memcpy(transformed_key_set, master_key_set, sizeof(key_set_t));
	}
	
	transformed_key_set->auth_key[0] ^= modifier;
	transformed_key_set->crypt_key[0] ^= modifier;
	
	CRYPTO_Step(number_steps+57, transformed_key_set->auth_key);
	CRYPTO_Step(number_steps+57, transformed_key_set->crypt_key);
}

uint32_t CRYPTO_SerialDecryptWord(uint32_t *pu32, uint32_t u32Word)
{
    return CRYPTO_ParallelPseudoRandomNumberGenerator(pu32) ^ u32Word;
}

uint32_t CRYPTO_SerialComputeSignature(uint32_t *pu32, uint32_t u32Word)
{
    pu32[0] ^= u32Word;
    return CRYPTO_ParallelPseudoRandomNumberGenerator(pu32) ^ u32Word;
}

uint32_t CRYPTO_SerialEncryptWord(uint32_t *pu32, uint32_t u32Word)
{
    return CRYPTO_ParallelPseudoRandomNumberGenerator(pu32) ^ u32Word;
}


////////////////////////////////////////////////////////////////////////////////
//!
//!   Name:          uint32_t CRYPTO_EncryptBlock(key_set_t*pKeys, uint32_t *pBlock, int iPayloadLength)
//!
//!   Type:          
//!
//!   Description:   Encryts a block and returns an encrypted signature.   To decrypt, the
//!                  decript/authenticate function must be called passing in the encrypted 
//!                  signature and the keys must be in the exact same state as passed
//!                  into the encrypt function.
//!                  
//!
//!   Inputs:        key_set_t *pKeys           : Keys for the encryption algorithm to use
//!                  uint32_t  *pBlock          : Pointer to block of data to encrypt
//!                  uint16_t   u16PayloadLength: Length of block of data (in words)
//!
//!   Outputs:       return value :  encrypted authetication signature
//!                                  Key structure pointed to by pKeys is modified
//!                                  Buffer pointed to by pBlock is encrypted
//!   Notes:         The encryption/decryption algorithm currently chosen is serial, and order
//!                  of encryption/decryption matters.
//!
////////////////////////////////////////////////////////////////////////////////
uint32_t CRYPTO_EncryptBlock(key_set_t*pKeys, uint32_t *pBlock, uint16_t u16PayloadLength)
{
    int i;
    uint32_t u32Signature;
    for(i=0;i<u16PayloadLength;i++)
    {
        //authenticate accumulate
        u32Signature = CRYPTO_SerialComputeSignature(pKeys->auth_key, pBlock[i]);
        //encrypt
        pBlock[i]    = CRYPTO_SerialEncryptWord(pKeys->crypt_key, pBlock[i]);
    }
    //return the authentication signature
    return CRYPTO_SerialEncryptWord(pKeys->crypt_key, u32Signature);
}

////////////////////////////////////////////////////////////////////////////////
//!
//!   Name:          bool CRYPTO_DecryptAndAuthenticateBlock(key_set_t*pKeys, uint32_t *pBlock, int iPayloadLength, uint32_t u32EncryptedSignature)
//!
//!   Type:          
//!
//!   Description:   Decryts a block, checks the signature and returns an true or false.   If
//!                  authentication fails, then the block is zero'd out.
//!
//!   Inputs:        key_set_t *pKeys           : Keys for the encryption algorithm to use
//!                  uint32_t  *pBlock          : Pointer to block of data to encrypt
//!                  uint16_t  u16PayloadLength : Length of block of data (in words)
//!                  uint32_t  u32EncryptedSignature : Signature 
//!
//!   Outputs:       return value :  true/false if the code was authenticated
//!                                  Key structure pointed to by pKeys is modified
//!                                  Buffer pointed to by pBlock is decrypted
//!   Notes:         The encryption/decryption algorithm currently chosen is serial, and order
//!                  of encryption/decryption matters.
//!
////////////////////////////////////////////////////////////////////////////////
bool CRYPTO_DecryptAndAuthenticateBlock(key_set_t*pKeys, uint32_t *pBlock, uint16_t u16PayloadLength, uint32_t u32EncryptedSignature)
{
    int i;
    bool bAuthenticated = false;
    uint32_t u32Signature;
    for(i=0;i<u16PayloadLength;i++)
    {
        //decrypt
        pBlock[i]   =CRYPTO_SerialDecryptWord(pKeys->crypt_key, pBlock[i]); 
        //signature accumulate
        u32Signature=CRYPTO_SerialComputeSignature(pKeys->auth_key,pBlock[i]);
    }
    //decrypt signature and compare to computed signature
    if(CRYPTO_SerialDecryptWord(pKeys->crypt_key, u32EncryptedSignature) == u32Signature)
    {
        bAuthenticated= TRUE;
    }
    else
    {//clear out the block if it doesn't authenticate
        for(i=0;i<u16PayloadLength+1;i++)
            pBlock[i] = 0;
    }
    return bAuthenticated;
}
////////////////////////////////////////////////////////////////////////////////
//!
//!   Name:          bool CRYPTO_DecryptAndAuthenticateBlock(key_set_t*pKeys, uint32_t *pBlock, uint16_t u16PayloadLength, uint32_t u32EncryptedSignature)
//!
//!   Type:          
//!
//!   Description:   Decryts a block, checks the signature and returns an true or false.   If
//!                  authentication fails, then the block is zero'd out.
//!
//!   Inputs:        key_set_t *pKeys           : Keys for the encryption algorithm to use
//!                  uint32_t  *pBlock          : Pointer to block of data to encrypt
//!                  uint16_t   u16PayloadLength: Length of block of data (in words)
//!                  uint32_t  u32EncryptedSignature : Signature 
//!
//!   Outputs:       return value :  true/false if the code was authenticated
//!                                  Key structure pointed to by pKeys is modified
//!                                  Buffer pointed to by pBlock is decrypted
//!   Notes:         The encryption/decryption algorithm currently chosen is serial, and order
//!                  of encryption/decryption matters.
//!
////////////////////////////////////////////////////////////////////////////////
void CRYPTO_DecryptBlock(key_set_t*pKeys, uint32_t *pBlock, uint16_t u16PayloadLength)
{
    int i;
    int iAuthenticated = FALSE;
    for(i=0;i<u16PayloadLength;i++)
    {
        //decrypt
        pBlock[i]   =CRYPTO_SerialDecryptWord(pKeys->crypt_key, pBlock[i]); 
    }
}

#else // OLD_CRYPTO

#ifdef WIN32
#define inline
#endif 

#ifdef USE_ASM_PRNG
#define CRYPTO_ParallelPseudoRandomNumberGenerator CRYPTO_ParallelPseudoRandomNumberGenerator_ASM

//#define inline 
uint32_t CRYPTO_ParallelPseudoRandomNumberGenerator_ASM(uint32_t *pu32);
#else
inline uint32_t CRYPTO_ParallelPseudoRandomNumberGenerator(uint32_t *pu32)
{
     uint32_t u32_0;
     u32_0 = pu32[0];
     pu32[0] = pu32[1] ^ pu32[3]  ^ pu32[5]  ^ pu32[7] 
                       ^ pu32[11] ^ pu32[13] ^ pu32[0];
     pu32[1] = pu32[2];
     pu32[2] = pu32[2] ^ pu32[3];
     pu32[3] = pu32[4];
     pu32[4] = pu32[5];
     pu32[5] = pu32[6];
     pu32[6] = pu32[7];
     pu32[7] = pu32[7] ^ pu32[8];
     pu32[8] = pu32[9];
     pu32[9] = pu32[10];
     pu32[10]= pu32[11]>>1 | pu32[11]<<31;
     //pu32[10]= pu32[11]; uncomment to remove the bit diffusion
     pu32[11] = pu32[11] ^ pu32[12];
     pu32[12] = pu32[13];
     pu32[13] = pu32[14];
     pu32[14] = pu32[15];
     pu32[15] = u32_0;
     return pu32[0];
}
#endif
uint32_t CRYPTO_SerialDecryptWord(uint32_t *pu32, uint32_t u32Word)
{
    return CRYPTO_ParallelPseudoRandomNumberGenerator(pu32) ^ u32Word;
}

inline uint32_t CRYPTO_SerialComputeSignature(uint32_t *pu32, uint32_t u32Word)
{
    pu32[0] ^= u32Word;
    return CRYPTO_ParallelPseudoRandomNumberGenerator(pu32) ^ u32Word;
}

inline uint32_t CRYPTO_SerialEncryptWord(uint32_t *pu32, uint32_t u32Word)
{
    return CRYPTO_ParallelPseudoRandomNumberGenerator(pu32) ^ u32Word;
}


////////////////////////////////////////////////////////////////////////////////
//!
//!   Name:          uint32_t CRYPTO_EncryptBlock(key_set_t*pKeys, uint32_t *pBlock, int iPayloadLength)
//!
//!   Type:          
//!
//!   Description:   Encryts a block and returns an encrypted signature.   To decrypt, the
//!                  decript/authenticate function must be called passing in the encrypted 
//!                  signature and the keys must be in the exact same state as passed
//!                  into the encrypt function.
//!                  
//!
//!   Inputs:        key_set_t *pKeys           : Keys for the encryption algorithm to use
//!                  uint32_t  *pBlock          : Pointer to block of data to encrypt
//!                  uint16_t   u16PayloadLength: Length of block of data (in words)
//!
//!   Outputs:       return value :  encrypted authetication signature
//!                                  Key structure pointed to by pKeys is modified
//!                                  Buffer pointed to by pBlock is encrypted
//!   Notes:         The encryption/decryption algorithm currently chosen is serial, and order
//!                  of encryption/decryption matters.
//!
////////////////////////////////////////////////////////////////////////////////
uint32_t CRYPTO_EncryptBlock(key_set_t*pKeys, uint32_t *pBlock, uint32_t u32PayloadLength)
{
    uint32_t i;
    uint32_t u32Signature;
    uint32_t u32Crypt;
    for(i=0;i<=u32PayloadLength-4;i+=4)
    {
        //authenticate accumulate
        pKeys->auth_key[0] ^= pBlock[i+0];
        pKeys->auth_key[0] ^= pBlock[i+1];
        pKeys->auth_key[0] ^= pBlock[i+2];
        pKeys->auth_key[0] ^= pBlock[i+3];
        u32Signature=CRYPTO_ParallelPseudoRandomNumberGenerator(pKeys->auth_key);
        //encrypt
        u32Crypt = CRYPTO_ParallelPseudoRandomNumberGenerator(pKeys->crypt_key);
        pBlock[i+0]^= u32Crypt;
        pBlock[i+1]^= u32Crypt;
        pBlock[i+2]^= u32Crypt;
        pBlock[i+3]^= u32Crypt;
    }
    if(i!= u32PayloadLength)
    {
        u32Crypt = CRYPTO_ParallelPseudoRandomNumberGenerator(pKeys->crypt_key);
        for(;i<u32PayloadLength;i++)
        {
            pKeys->auth_key[0] ^= pBlock[i];
            pBlock[i] ^=u32Crypt; 
        }
        u32Signature=CRYPTO_ParallelPseudoRandomNumberGenerator(pKeys->auth_key);
    }

    //return the authentication signature
    return CRYPTO_ParallelPseudoRandomNumberGenerator(pKeys->crypt_key)^u32Signature;
}

////////////////////////////////////////////////////////////////////////////////
//!
//!   Name:          bool CRYPTO_DecryptAndAuthenticateBlock(key_set_t*pKeys, uint32_t *pBlock, int iPayloadLength, uint32_t u32EncryptedSignature)
//!
//!   Type:          
//!
//!   Description:   Decryts a block, checks the signature and returns an true or false.   If
//!                  authentication fails, then the block is zero'd out.
//!
//!   Inputs:        key_set_t *pKeys           : Keys for the encryption algorithm to use
//!                  uint32_t  *pBlock          : Pointer to block of data to encrypt
//!                  uint16_t  u16PayloadLength : Length of block of data (in words)
//!                  uint32_t  u32EncryptedSignature : Signature 
//!
//!   Outputs:       return value :  true/false if the code was authenticated
//!                                  Key structure pointed to by pKeys is modified
//!                                  Buffer pointed to by pBlock is decrypted
//!   Notes:         The encryption/decryption algorithm currently chosen is serial, and order
//!                  of encryption/decryption matters.
//!
////////////////////////////////////////////////////////////////////////////////
bool CRYPTO_DecryptAndAuthenticateBlock(key_set_t*pKeys, uint32_t *pBlock, uint32_t u32PayloadLength, uint32_t u32EncryptedSignature)
{
    uint32_t i;
    bool bAuthenticated = false;
    for(i=0;i<=u32PayloadLength-4;i+=4)
    {
        uint32_t u32Crypt;
        //decrypt
        u32Crypt = CRYPTO_ParallelPseudoRandomNumberGenerator(pKeys->crypt_key);
        pBlock[i+0] ^=u32Crypt; 
        pBlock[i+1] ^=u32Crypt; 
        pBlock[i+2] ^=u32Crypt; 
        pBlock[i+3] ^=u32Crypt; 
        //signature accumulate
        pKeys->auth_key[0] = pKeys->auth_key[0]^ pBlock[i+0] ^ pBlock[i+1] ^ pBlock[i+2] ^ pBlock[i+3];
        CRYPTO_ParallelPseudoRandomNumberGenerator(pKeys->auth_key);
    }
    if(i!= u32PayloadLength)
    {
        uint32_t u32Crypt;
        u32Crypt = CRYPTO_ParallelPseudoRandomNumberGenerator(pKeys->crypt_key);
        for(;i<u32PayloadLength;i++)
        {
            pBlock[i] ^=u32Crypt; 
            pKeys->auth_key[0] ^= pBlock[i];
        }
        CRYPTO_ParallelPseudoRandomNumberGenerator(pKeys->auth_key);
    }
    //decrypt signature and compare to computed signature
    if(CRYPTO_SerialDecryptWord(pKeys->crypt_key, u32EncryptedSignature) == pKeys->auth_key[0])
    {
        bAuthenticated= TRUE;
    }
    else
    {//clear out the block if it doesn't authenticate
        for(i=0;i<u32PayloadLength+1;i++)
            pBlock[i] = 0;
    }
    return bAuthenticated;
}

void CRYPTO_Step(uint32_t number_steps, uint32_t * pu32)
{
	unsigned i;
	for (i = 0; i < number_steps; ++i)
	{
		CRYPTO_ParallelPseudoRandomNumberGenerator(pu32);
	}
}

void CRYPTO_Transform_Key_Set(uint32_t u32ModifierValue, uint32_t number_steps, key_set_t *pOriginal, key_set_t *pKeys)
{
    *pKeys = *pOriginal;
    pKeys->auth_key[0] ^= u32ModifierValue;
    pKeys->crypt_key[0]^= u32ModifierValue;

	CRYPTO_Step(number_steps+57, pKeys->auth_key);
	CRYPTO_Step(number_steps+57, pKeys->crypt_key);

}

#endif // OLD_CRYPTO
