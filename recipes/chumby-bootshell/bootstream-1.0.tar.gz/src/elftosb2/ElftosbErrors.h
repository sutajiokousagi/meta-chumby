/*
 * File:	ConversionController.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_ElftosbErrors_h_)
#define _ElftosbErrors_h_

#include <string>
#include <stdexcept>

namespace elftosb
{

/*!
 * \brief A semantic error discovered while processing the command file AST.
 */
class semantic_error : public std::runtime_error
{
public:
	explicit semantic_error(const std::string & msg)
	:	std::runtime_error(msg)
	{}
};

}; // namespace elftosb

#endif // _ElftosbErrors_h_
