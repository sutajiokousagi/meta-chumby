/*
 * File:	StLFSREncrypter.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_StLFSREncrypter_h_)
#define _StLFSREncrypter_h_

#include "stdafx.h"
#include "StEncrypter.h"
#include "StKeySet.h"

/*!
 * \brief The LFSR encryption algorithm used by the 3600 bootloader.
 */
class StLFSREncrypter : public StEncrypter
{
public:
	//! \brief Constructor.
	StLFSREncrypter(const StKeySet & inKeySet);
	
	//! \brief Destructor.
	virtual ~StLFSREncrypter();
	
	//! \brief Encrypt \a inData in-place and return the signature for that data.
	virtual uint32_t encryptAndSign(uint8_t * inData, unsigned inLength);
	
	//! \brief Decrypt \a inData in-place and return whether not it matches \a inSignature.
	virtual bool decryptAndAuthenticate(uint8_t * inData, unsigned inLength, uint32_t inSignature);

protected:
	StKeySet m_keys;	//!< The keys used to encrypt and sign.
};

#endif // _StLFSREncrypter_h_
