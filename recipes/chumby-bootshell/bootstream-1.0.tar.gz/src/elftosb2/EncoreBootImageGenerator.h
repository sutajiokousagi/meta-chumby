/*
 * File:	EncoreBootImageGenerator.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_EncoreBootImageGenerator_h_)
#define _EncoreBootImageGenerator_h_

#include "BootImageGenerator.h"
#include "EncoreBootImage.h"

namespace elftosb
{

/*!
 * \brief Generator for Encore boot images.
 *
 * Takes the abstract model of the output file and processes it into a
 * concrete boot image for the STMP37xx.
 */
class EncoreBootImageGenerator : public BootImageGenerator
{
public:
	//! \brief Default constructor.
	EncoreBootImageGenerator() : BootImageGenerator() {}
	
	//! \brief Builds the resulting boot image from previously added output sections.
	virtual BootImage * generate();
	
protected:
	void processOptions(EncoreBootImage * image);
	void processSectionOptions(EncoreBootImage::Section * imageSection, OutputSection * modelSection);
	
	void processOperationSection(OperationSequenceSection * section, EncoreBootImage * image);
	void processDataSection(BinaryDataSection * section, EncoreBootImage * image);

	void processLoadOperation(LoadOperation * op, EncoreBootImage::BootSection * section);
	void processExecuteOperation(ExecuteOperation * op, EncoreBootImage::BootSection * section);
	void processBootModeOperation(BootModeOperation * op, EncoreBootImage::BootSection * section);
	
	void setFillPatternFromValue(EncoreBootImage::FillCommand & command, SizedIntegerValue & pattern);
};

}; // namespace elftosb

#endif // _EncoreBootImageGenerator_h_

