/*
 * File:	elftosb.h
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */
#if !defined(_elftosb_h_)
#define _elftosb_h_

#include <string>
#include <list>

//! String type used for command line arguments.
typedef std::string ArgString;

//! List of command list arguments.
typedef std::list<ArgString> ArgList;

#endif // _elftosb_h_
