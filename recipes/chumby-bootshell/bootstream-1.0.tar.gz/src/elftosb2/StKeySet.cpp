/*
 * File:	StKeySet.cpp
 *
 * Copyright (c) SigmaTel, Inc. All rights reserved.
 *
 * SigmaTel, Inc.
 * Proprietary & Confidential
 *
 * This source code and the algorithms implemented therein constitute
 * confidential information and may comprise trade secrets of SigmaTel, Inc.
 * or its associates, and any use thereof is subject to the terms and
 * conditions of the Confidential Disclosure Agreement pursual to which this
 * source code was originally received.
 */

#include "StKeySet.h"
#include <string.h>
#include <stdexcept>

//! Sets the keys set to all zeroes.
//!
StKeySet::StKeySet()
{
	memset(&m_keys, 0, sizeof(m_keys));
}

//! The \a keyData is copied into the new instance of StKeySet, so
//! it does not have to be retained by the caller.
//!
//! Because a size is not passed in, this constructor assumes that there
//! is enough data to form the full key set. It is the caller's responsibility
//! to ensure that this is true.
StKeySet::StKeySet(const unsigned char * keyData)
{
    memcpy(&m_keys, keyData, sizeof(m_keys));
}

StKeySet::StKeySet(key_set_t & inKeys)
{
	memcpy(&m_keys, &inKeys, sizeof(m_keys));
}

StKeySet::StKeySet(const StKeySet & inOther)
{
	memcpy(&m_keys, &inOther.m_keys, sizeof(m_keys));
}

StKeySet::~StKeySet()
{
}

//! The input stream must have been opened as a binary stream. It is also expected 
//! to be at least 128 bytes in length, and. That is for sixteen 32-bit keys each
//! for encryption and authentication. The authentication keys are the first 16 keys,
//! followed by the 16 encryption keys. Individual keys should be in
//! little-endian byte order.
//! \param inStream The binary input stream to read keys from.
//! \exception std::runtime_error Thrown if either the encryption or authentication
//!		keys cannot be read from the stream.
void StKeySet::readFromStream(std::istream & inStream)
{
	// read authentication keys
	inStream.read(reinterpret_cast<char *>(&m_keys.auth_key), sizeof(m_keys.auth_key));
	if (inStream.bad())
		throw std::runtime_error("failed to read authentication keys");
	
	// read encryption keys
	inStream.read(reinterpret_cast<char *>(&m_keys.crypt_key), sizeof(m_keys.crypt_key));
	if (inStream.bad())
		throw std::runtime_error("failed to read encryption keys");
}

void StKeySet::transform(uint32_t inTransformCode, uint32_t inSpinSteps)
{
#if OLD_CRYPTO
	CRYPTO_TransformKeySet(inTransformCode, inSpinSteps, &m_keys, &m_keys);
#else
	CRYPTO_Transform_Key_Set(inTransformCode, inSpinSteps, &m_keys, &m_keys);
#endif
}

StKeySet & StKeySet::operator = (const StKeySet & inOther)
{
	memcpy(&m_keys, &inOther.m_keys, sizeof(m_keys));
	return *this;
}

